"# python-for-data-science-IPD" 
Cours 1: Introduction

Cours 2:infor

